// js/header-loader.js
// Central site loader: header + one common feedback system.

(function () {
  const currentPath = window.location.pathname;

  // Do not load the public feedback widget on the Admin panel.
  const isAdminPage = currentPath.endsWith("/admin-comments.html");

  let container = document.getElementById("header-container");

  if (!container) {
    container = document.createElement("div");
    container.id = "header-container";
    document.body.insertBefore(container, document.body.firstChild);
  }

  function highlightActiveLink() {
    const path = window.location.pathname.replace(/\/$/, "") || "/";
    const links = container.querySelectorAll("nav a");

    links.forEach(link => {
      link.classList.remove("active");

      const raw =
        link.dataset.match ||
        link.getAttribute("href");

      if (!raw) return;

      const candidates = raw.split(",");

      const active = candidates.some(match => {
        if (match === "/") return path === "/" || path === "";
        return path === match || path.startsWith(match);
      });

      if (active) link.classList.add("active");
    });
  }

  function loadHeader() {
    fetch("/header.html", { cache: "no-cache" })
      .then(response => {
        if (!response.ok) throw new Error("Header not found");
        return response.text();
      })
      .then(html => {
        container.innerHTML = html;
        highlightActiveLink();
      })
      .catch(error => {
        console.warn("Header load failed:", error);
      });
  }

  function loadFeedbackSystem() {
    if (isAdminPage) return;

    // Never load the common module more than once.
    if (window.__itiFeedbackLoading || window.__itiFeedbackLoaded) return;

    // Remove any legacy/manual comments.js tags left by an old page.
    document
      .querySelectorAll('script[src*="/js/comments.js"]')
      .forEach(script => script.remove());

    window.__itiFeedbackLoading = true;

    const script = document.createElement("script");
    script.type = "module";
    script.src = "/js/comments.js?v=20260818";
    script.dataset.itiFeedback = "true";

    script.addEventListener("load", () => {
      window.__itiFeedbackLoaded = true;
      window.__itiFeedbackLoading = false;
    });

    script.addEventListener("error", () => {
      window.__itiFeedbackLoading = false;
      console.error("Common feedback system could not be loaded.");
    });

    document.body.appendChild(script);
  }

  function start() {
    loadHeader();
    loadFeedbackSystem();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();

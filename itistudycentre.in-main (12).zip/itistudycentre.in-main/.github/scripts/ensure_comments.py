"""
Comment System Auto-Enable
---------------------------
Har push par ye script scan karta hai ki content sections
(notes/, engineering/, question-bank/, online-test.html) ke
andar koi bhi HTML page hai jisme /js/header-loader.js nahi
laga hua — agar mile to khud add kar deta hai.

Isse comment system HAR NAYE PAGE par automatically apply ho
jata hai, chahe woh page kaise bhi banaya gaya ho.

NOTE: content_prefixes yahan aur js/header-loader.js dono jagah
sync rehni chahiye — agar future me koi naya section (jaise news/)
add karna ho, to dono jagah update karna.
"""

import glob
import os

content_prefixes = ("notes/", "engineering/", "question-bank/")
content_exact = ("online-test.html",)

script_tag = '<script defer src="/js/header-loader.js"></script>'

fixed = []

for filepath in glob.glob("**/*.html", recursive=True):
    if "/.git/" in filepath or filepath.startswith(".git/"):
        continue

    normalized = filepath.replace(os.sep, "/")
    is_content_page = normalized.startswith(content_prefixes) or normalized in content_exact
    if not is_content_page:
        continue

    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    if "header-loader.js" in content:
        continue

    if "</body>" in content:
        new_content = content.replace("</body>", "    " + script_tag + "\n</body>", 1)
    else:
        new_content = content + "\n" + script_tag + "\n"

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(new_content)

    fixed.append(filepath)
    print(f"Comment system enabled: {filepath}")

if not fixed:
    print("Koi naya page nahi mila jisme fix karna ho - sab pehle se theek hain.")
else:
    print(f"Total {len(fixed)} pages me comment system auto-enable kiya gaya.")

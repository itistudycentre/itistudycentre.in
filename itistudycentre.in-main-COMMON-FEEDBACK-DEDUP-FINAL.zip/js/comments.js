/* ============================================================
   ITI Study Centre — Centralized Feedback System
   File: /js/comments.js

   One common system for every public page:
   - 💬 टिप्पणी: public after Admin approval
   - 💡 सुझाव: sent to Admin for review; not shown publicly
   - Both use the same Firestore "comments" collection.
   ============================================================ */

import {
  initializeApp,
  getApps,
  getApp
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-app.js";

import {
  initializeAppCheck,
  ReCaptchaV3Provider
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-app-check.js";

import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  query,
  where,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAyBiDGQx5LEtIV5JtMOT79rU3ksQg8TE",
  authDomain: "iti-study-centre.firebaseapp.com",
  projectId: "iti-study-centre",
  storageBucket: "iti-study-centre.firebasestorage.app",
  messagingSenderId: "690794814318",
  appId: "1:690794814318:web:42ed1c1f582a9e1df5bf7f"
};

const RECAPTCHA_SITE_KEY =
  "6LexjYctAAAAAJdA17IjqdkfJrecHtmqnd-DoODv";

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

if (!window.__itiAppCheckInitialized) {
  try {
    initializeAppCheck(app, {
      provider: new ReCaptchaV3Provider(RECAPTCHA_SITE_KEY),
      isTokenAutoRefreshEnabled: true
    });
  } catch (e) {
    console.warn("App Check initialization:", e);
  }
  window.__itiAppCheckInitialized = true;
}

const db = getFirestore(app);

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = value == null ? "" : String(value);
  return div.innerHTML;
}

function getPagePath() {
  let path = window.location.pathname;
  if (path.length > 1 && path.endsWith("/")) path = path.slice(0, -1);
  return path || "/";
}

function timeAgo(date) {
  if (!date) return "";
  const diff = Date.now() - date.getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return "अभी-अभी";
  if (min < 60) return `${min} मिनट पहले`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr} घंटे पहले`;
  return `${Math.floor(hr / 24)} दिन पहले`;
}

function injectStyles() {
  if (document.getElementById("iti-feedback-styles")) return;

  const style = document.createElement("style");
  style.id = "iti-feedback-styles";
  style.textContent = `
    #comment-section{
      width:100%;
      max-width:1000px;
      margin:30px auto;
      padding:0 15px;
      box-sizing:border-box;
    }

    .iti-feedback-wrap{
      background:#fff;
      border:1px solid #e6eaef;
      border-radius:14px;
      padding:18px 20px;
      box-shadow:0 2px 10px rgba(0,0,0,.04);
    }

    .iti-feedback-title{
      margin:0 0 5px;
      color:#003366;
      font-size:1.15rem;
      font-weight:700;
    }

    .iti-feedback-note{
      margin:0 0 13px;
      color:#777;
      font-size:.82rem;
      line-height:1.5;
    }

    .iti-feedback-tabs{
      display:flex;
      gap:8px;
      margin-bottom:13px;
      flex-wrap:wrap;
    }

    .iti-feedback-tab{
      border:1px solid #d6dce4;
      background:#f4f6f9;
      color:#003366;
      border-radius:7px;
      padding:7px 13px;
      font-size:.86rem;
      font-weight:600;
      cursor:pointer;
    }

    .iti-feedback-tab.active{
      background:#003366;
      color:#fff;
      border-color:#003366;
    }

    .iti-feedback-field{
      width:100%;
      padding:10px 13px;
      border:1px solid #ccc;
      border-radius:8px;
      font-size:.94rem;
      font-family:inherit;
      margin-bottom:9px;
      box-sizing:border-box;
    }

    .iti-feedback-field:focus{
      outline:none;
      border-color:#003366;
    }

    .iti-feedback-row{
      display:flex;
      gap:9px;
      flex-wrap:wrap;
    }

    .iti-feedback-row .iti-feedback-field{
      flex:1 1 220px;
    }

    .iti-feedback-submit{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      background:#003366;
      color:#fff;
      border:0;
      border-bottom:2px solid #ffcc00;
      border-radius:7px;
      padding:8px 15px;
      font-size:.86rem;
      font-weight:600;
      cursor:pointer;
    }

    .iti-feedback-submit:hover{opacity:.92;}
    .iti-feedback-submit:disabled{opacity:.6;cursor:not-allowed;}

    .iti-feedback-message{
      margin-top:9px;
      padding:9px 12px;
      border-radius:7px;
      font-size:.85rem;
      display:none;
    }

    .iti-feedback-message.show{display:block;}
    .iti-feedback-message.ok{
      background:#eaf7ea;
      color:#256029;
      border:1px solid #b6e2b6;
    }
    .iti-feedback-message.err{
      background:#fdecea;
      color:#a33;
      border:1px solid #f3b6b6;
    }

    .iti-feedback-list{
      margin-top:16px;
      max-height:420px;
      overflow-y:auto;
    }

    .iti-feedback-item{
      background:#f9fafc;
      border:1px solid #e6eaef;
      border-radius:10px;
      padding:11px 14px;
      margin-bottom:9px;
    }

    .iti-feedback-item strong{color:#003366;}
    .iti-feedback-meta{
      color:#888;
      font-size:.78rem;
      margin-left:7px;
    }

    .iti-feedback-item p{
      margin:5px 0 0;
      color:#1e2a3a;
      font-size:.93rem;
      white-space:pre-wrap;
      word-break:break-word;
    }

    .iti-feedback-empty{
      color:#888;
      font-size:.87rem;
      font-style:italic;
    }

    .iti-feedback-hp{
      position:absolute!important;
      left:-9999px!important;
      opacity:0!important;
      width:1px!important;
      height:1px!important;
    }

    @media(max-width:520px){
      #comment-section{padding:0 10px;}
      .iti-feedback-wrap{padding:15px;}
      .iti-feedback-row{display:block;}
      .iti-feedback-submit{padding:8px 13px;font-size:.84rem;}
    }
  `;
  document.head.appendChild(style);
}

function createContainer() {
  let container = document.getElementById("comment-section");
  if (container) return container;

  container = document.createElement("section");
  container.id = "comment-section";

  // Prefer the footer if it already exists.
  const footer = document.querySelector("footer");
  if (footer) {
    footer.parentNode.insertBefore(container, footer);
    return container;
  }

  const main = document.querySelector("main");
  if (main) {
    main.insertAdjacentElement("afterend", container);
    return container;
  }

  document.body.appendChild(container);
  return container;
}

function renderShell(container) {
  container.innerHTML = `
    <div class="iti-feedback-wrap">
      <p class="iti-feedback-title">💬 टिप्पणी और सुझाव</p>
      <p class="iti-feedback-note">
        इस पेज के बारे में टिप्पणी करें या कोई सुधार/नया विषय सुझाएँ।
        टिप्पणियाँ प्रकाशित होने से पहले एडमिन द्वारा समीक्षा की जाती हैं।
      </p>

      <div class="iti-feedback-tabs" role="tablist">
        <button type="button" class="iti-feedback-tab active" data-mode="comment">
          💬 टिप्पणी
        </button>
        <button type="button" class="iti-feedback-tab" data-mode="suggestion">
          💡 सुझाव दें
        </button>
      </div>

      <form id="iti-feedback-form">
        <div class="iti-feedback-row">
          <input
            id="iti-feedback-name"
            class="iti-feedback-field"
            type="text"
            maxlength="80"
            autocomplete="name"
            placeholder="आपका नाम (वैकल्पिक)"
          >
          <input
            id="iti-feedback-email"
            class="iti-feedback-field"
            type="email"
            maxlength="150"
            autocomplete="email"
            placeholder="आपका ईमेल (वैकल्पिक)"
          >
        </div>

        <textarea
          id="iti-feedback-text"
          class="iti-feedback-field"
          rows="3"
          maxlength="2000"
          required
          placeholder="अपनी टिप्पणी यहाँ लिखें..."
        ></textarea>

        <input
          id="iti-feedback-website"
          class="iti-feedback-hp"
          type="text"
          tabindex="-1"
          autocomplete="off"
        >

        <button
          id="iti-feedback-submit"
          class="iti-feedback-submit"
          type="submit"
        >
          💬 टिप्पणी पोस्ट करें
        </button>

        <div id="iti-feedback-status" class="iti-feedback-message"></div>
      </form>

      <div id="iti-feedback-list" class="iti-feedback-list">
        <p class="iti-feedback-empty">टिप्पणियाँ लोड हो रही हैं...</p>
      </div>
    </div>
  `;
}

function setMode(container, mode) {
  const isSuggestion = mode === "suggestion";

  container.dataset.mode = mode;

  container.querySelectorAll(".iti-feedback-tab").forEach(button => {
    button.classList.toggle("active", button.dataset.mode === mode);
  });

  const text = container.querySelector("#iti-feedback-text");
  const submit = container.querySelector("#iti-feedback-submit");

  text.placeholder = isSuggestion
    ? "इस पेज में क्या सुधार, नया विषय या सुझाव होना चाहिए?"
    : "अपनी टिप्पणी यहाँ लिखें...";

  submit.textContent = isSuggestion
    ? "💡 सुझाव भेजें"
    : "💬 टिप्पणी पोस्ट करें";

  loadApprovedComments(container, getPagePath());
}

function showStatus(el, text, ok) {
  el.textContent = text;
  el.className = `iti-feedback-message show ${ok ? "ok" : "err"}`;
}

async function loadApprovedComments(container, page) {
  const list = container.querySelector("#iti-feedback-list");
  if (!list) return;

  try {
    const q = query(
      collection(db, "comments"),
      where("page", "==", page),
      where("status", "==", "approved")
    );

    const snap = await getDocs(q);
    const items = [];

    snap.forEach(docSnap => {
      const data = docSnap.data();

      // Suggestions are admin-only and must never appear publicly.
      if ((data.type || "comment") !== "comment") return;

      items.push({
        name: data.name || "Anonymous",
        message: data.message || "",
        createdAt:
          data.createdAt && data.createdAt.toDate
            ? data.createdAt.toDate()
            : null
      });
    });

    items.sort(
      (a, b) =>
        (b.createdAt ? b.createdAt.getTime() : 0) -
        (a.createdAt ? a.createdAt.getTime() : 0)
    );

    if (!items.length) {
      list.innerHTML =
        `<p class="iti-feedback-empty">अभी तक कोई स्वीकृत टिप्पणी नहीं है।</p>`;
      return;
    }

    list.innerHTML = items
      .map(
        item => `
          <div class="iti-feedback-item">
            <strong>${escapeHtml(item.name)}</strong>
            <span class="iti-feedback-meta">
              ${escapeHtml(timeAgo(item.createdAt))}
            </span>
            <p>${escapeHtml(item.message)}</p>
          </div>
        `
      )
      .join("");
  } catch (error) {
    console.error("Comments load error:", error);
    list.innerHTML =
      `<p class="iti-feedback-empty">टिप्पणियाँ लोड नहीं हो सकीं। बाद में पुनः प्रयास करें।</p>`;
  }
}

function bindForm(container, page) {
  const form = container.querySelector("#iti-feedback-form");
  const status = container.querySelector("#iti-feedback-status");
  const submit = container.querySelector("#iti-feedback-submit");

  form.addEventListener("submit", async event => {
    event.preventDefault();

    if (container.querySelector("#iti-feedback-website").value) return;

    const mode = container.dataset.mode || "comment";
    const name = container
      .querySelector("#iti-feedback-name")
      .value.trim()
      .slice(0, 80);

    const email = container
      .querySelector("#iti-feedback-email")
      .value.trim()
      .slice(0, 150);

    const message = container
      .querySelector("#iti-feedback-text")
      .value.trim()
      .slice(0, 2000);

    if (!message) {
      showStatus(
        status,
        mode === "suggestion"
          ? "कृपया अपना सुझाव लिखें।"
          : "कृपया टिप्पणी लिखें।",
        false
      );
      return;
    }

    submit.disabled = true;
    submit.textContent =
      mode === "suggestion" ? "सुझाव भेजा जा रहा है..." : "टिप्पणी भेजी जा रही है...";

    try {
      await addDoc(collection(db, "comments"), {
        name: name || "Anonymous",
        email: email || "",
        message,
        page,
        type: mode,
        category: mode,
        status: "pending",
        createdAt: serverTimestamp()
      });

      form.reset();

      showStatus(
        status,
        mode === "suggestion"
          ? "✅ आपका सुझाव एडमिन को भेज दिया गया है।"
          : "✅ आपकी टिप्पणी समीक्षा के लिए भेज दी गई है।",
        true
      );

      submit.textContent =
        mode === "suggestion"
          ? "💡 सुझाव भेजें"
          : "💬 टिप्पणी पोस्ट करें";
    } catch (error) {
      console.error("Feedback submit error:", error);

      showStatus(
        status,
        "❌ भेजने में समस्या हुई। कृपया पुनः प्रयास करें।",
        false
      );

      submit.textContent =
        mode === "suggestion"
          ? "💡 सुझाव भेजें"
          : "💬 टिप्पणी पोस्ट करें";
    } finally {
      submit.disabled = false;
    }
  });
}

function initComments() {
  // Admin page uses its own authenticated panel.
  if (window.location.pathname.endsWith("/admin-comments.html")) return;

  const container = createContainer();
  if (!container) return;

  injectStyles();
  renderShell(container);
  container.dataset.mode = "comment";

  container.querySelectorAll(".iti-feedback-tab").forEach(button => {
    button.addEventListener("click", () => {
      setMode(container, button.dataset.mode);
    });
  });

  bindForm(container, getPagePath());
  loadApprovedComments(container, getPagePath());
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initComments, { once: true });
} else {
  initComments();
}
